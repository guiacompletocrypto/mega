# Nuvem Empresarial

Aplicação privada de armazenamento de arquivos em Node.js 24, com interface inspirada em serviços corporativos modernos.

## Requisitos
- Windows 10/11
- Node.js 24.x

## Instalação
```cmd
npm install
npm start
```
Acesse http://localhost:3000

Login inicial:
- E-mail: diegomxs5@gmail.com
- Senha: 123456

## Estrutura
- `storage/` arquivos dos usuários
- `trash/` reservado para recursos futuros
- `database.db` banco SQLite nativo do Node
- `public/` interface web

## Observação
Troque a senha inicial e o segredo de sessão antes de expor o serviço à internet.
