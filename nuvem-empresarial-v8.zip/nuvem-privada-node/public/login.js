async function login(){
  const msg=document.getElementById('msg'); msg.textContent='';
  try{
    const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:document.getElementById('email').value,password:document.getElementById('password').value})});
    const j=await r.json().catch(()=>({}));
    if(!r.ok) throw Error(j.error||'Não foi possível entrar');
    location.replace('/');
  }catch(e){msg.textContent=e.message}
}
